package com.info.security.oauth2;

import java.util.Collection;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;

public interface OAuth2User {
	
	String getName();

	Collection<? extends GrantedAuthority> getAuthorities();

	Map<String, Object> getAttributes();

	String getAttribute(String string);


}
