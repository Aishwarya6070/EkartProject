package com.info.security.oauth2;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;

import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;

import org.springframework.security.core.GrantedAuthority;

import org.springframework.security.core.GrantedAuthority;

public class CustomOAuth2User implements OAuth2User {
	
	private OAuth2User oauth2User;
	
	

	public CustomOAuth2User(OAuth2User oauth2User) {
		
		this.oauth2User = oauth2User;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return getName();
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return oauth2User.getAuthorities();
	}

	@Override
	public Map<String, Object> getAttributes() {
		// TODO Auto-generated method stub
		return oauth2User.getAttributes();
	}

	

	
	
	}
	
	



	
		
		


