package com.info.model;

public enum AuthenticationProvider {
	LOCAL, GOOGLE

}
